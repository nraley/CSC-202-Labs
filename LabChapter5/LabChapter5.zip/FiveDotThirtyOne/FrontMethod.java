package LabChapter5.FiveDotThirtyOne;

import LabChapter5.LinkedUnbndQueue;

/**
 * Created by nraley on 11/16/15.
 */
public class FrontMethod<T> extends LinkedUnbndQueue<T> {

    public T front() {
        return front.getInfo();
    }
}